import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;

public class DbMethods {

	static ConsoleMethods cm = new ConsoleMethods();

	public void Reg() {
		try {
			Class.forName("org.sqlite.JDBC"); 															// DRIVER REGISZTRALAS
			SM("Sikeres driver regisztrálás");
		} catch (Exception ex) {
			SM(ex.getMessage());
		}
	}

	public void SM(String s) {
		System.out.println(s + "\n");
	}

	public Connection Connect() {
		Connection conn = null;
		String url = "jdbc:sqlite:C:/Users/olisz/sqlite3/hadseregdb"; 									// DRIVER CONNECT
		try {
			conn = DriverManager.getConnection(url);
			SM("Sikeres kapcsolódás");
			return conn;
		} catch (Exception ex) {
			SM(ex.getMessage());
			return conn;
		}
	}

	public void DisConnect(Connection conn) {
		if (conn != null) {
			try {
				conn.close();
				SM("Sikeres lekapcsolódás");
			} catch (Exception ex) {
				SM(ex.getMessage());
			}
		} 																								// DRIVER KILEPES
	}

	public void CommandExec(String command) { 															// COMMAND VEGREHAJTAS
		Connection conn = Connect();
		String sqlp = command;
		try {
			Statement s = conn.createStatement();
			s.execute(sqlp);
			SM("Command: " + sqlp);
			SM("Command OK!");
		} catch (SQLException e) {
			SM("Command: " + sqlp);
			SM("CommandExec: " + e.getMessage());
		}
		DisConnect(conn);
	}

	public void createTable() throws SQLException { 													// TABLAK KESZITESE

		Connection conn = Connect();

		Statement state = conn.createStatement();

		state.execute("CREATE TABLE Users (username char(30), psw char(20))");

		state.execute(
				"CREATE TABLE Tisztek (azonosító char(6) primary key, név char(30), rang char(20), életkor number(3), szolgKezdete char(10))");

		state.execute(
				"CREATE TABLE Katonak (sorszám char(6) primary key, név char(30), rang char(20), életkor number(3), sorszámFK char(6), FOREIGN KEY(sorszámFK) REFERENCES Tisztek(azonosító))");
	}

	public void insertUsers() { 																		// USERS INSERT

		String username = "admin";
		String psw = "admin";

		Connection connect = Connect();
		String sqlp = "INSERT INTO Users Values('" + username + "','" + psw + "')";
		try {
			Statement state = connect.createStatement();
			state.execute(sqlp);
			SM("Insert OK!");
		} catch (SQLException e) {
			SM("JDBC Insert: " + e.getMessage());
		}
		DisConnect(connect);

	}

	public void insertTisztek() 																		// TISZTEK INSERT
			throws SQLException {

		String azonosító = "", név = "", rang = "", szolgKezdete = "";
		int életkor = 0;

		SM("Tiszt adatainak beolvasása ");

		do {
			azonosító = cm.ReadData("Adja meg az azonosítóját: ");

		} while ((azonosító.length() != 6));

		név = cm.ReadData("Adja meg a tiszt nevét: ");

		rang = cm.ReadData("Adja meg a tiszt rangját: ");

		boolean datum = false;
		do {
			szolgKezdete = cm.ReadData("Adja meg a szolgalat kezdetenek idopontjat (yyyy-hh-dd):  ");

			String[] parts = szolgKezdete.split("-");
			String part1 = parts[0];
			String part2 = parts[1];
			String part3 = parts[2];
			datum = true;

			if (((Integer.parseInt(part1) <= 0) || (Integer.parseInt(part2) <= 0)) || (Integer.parseInt(part3) <= 0)) {

				SM("Kisebb vagy egyenlő nullával! ");
				datum = false;

			}

			if ((part1.length() != 4) || (part2.length() != 2) || (part3.length() != 2)) {

				SM("Hibás formátum! ");
				datum = false;

			}

			if ((Integer.parseInt(part2) > 12) || (Integer.parseInt(part3) > 30)) {

				SM("Túl nagy értékek! ");
				datum = false;

			}

		} while (datum == false);

		do {

			életkor = cm.ReadDataInt("Adja meg az életkorát: ");

		} while (életkor < 18 || életkor > 60);

		Connection connect = Connect();
		String sqlp = "INSERT INTO Tisztek Values('" + azonosító + "','" + név + "','" + rang + "'," + életkor + ", '"
				+ szolgKezdete + "')";
		try {
			Statement state = connect.createStatement();
			state.execute(sqlp);
			SM("Insert OK!");
		} catch (SQLException e) {
			SM("JDBC Insert: " + e.getMessage());
		}
		DisConnect(connect);

		cm.FoMenu();

	}

	public void insertKatonak() 																		// KATONAK INSERT
			throws SQLException {

		String sorszám = "", név = "", rang = "", sorszámFK = "";
		int életkor = 0;

		SM("Katona adatainak beolvasasa ");

		do {
			sorszám = cm.ReadData("Adja meg a sorszámot: ");

		} while (sorszám.length() != 6);

		név = cm.ReadData("Adja meg a katona nevét: ");

		rang = cm.ReadData("Adja meg a katona rangját: ");

		do {
			életkor = cm.ReadDataInt("Adja meg az életkorát: ");

		} while (életkor < 18 || életkor > 60);

		do {
			sorszámFK = cm.ReadData("Adja meg a tiszt azonositojat, aki alatt szolgal: : ");

		} while (sorszámFK.length() != 6);

		Connection connect = Connect();
		String sqlp = "INSERT INTO Katonak Values('" + sorszám + "','" + név + "','" + rang + "'," + életkor + ",'"
				+ sorszámFK + "')";
		try {
			Statement state = connect.createStatement();
			state.execute(sqlp);
			SM("Insert OK!");
		} catch (SQLException e) {
			SM("JDBC Insert: " + e.getMessage());
		}
		DisConnect(connect);

		cm.FoMenu();
	}

	public void ReadAllDataTisztek() throws SQLException { 												// TABLAK KIOLVAS TISZTEK

		String azonosító = "", név = "", rang = "", szolgKezdete = "", x = "\t";
		int életkor = 0;

		String sqlp = "SELECT azonosító, név, rang, életkor, szolgKezdete FROM Tisztek";

		Connection conn = Connect();

		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(sqlp);
			while (rs.next()) {
				azonosító = rs.getString("azonosító");
				név = rs.getString("név");
				rang = rs.getString("rang");
				életkor = rs.getInt("életkor");
				szolgKezdete = rs.getString("szolgKezdete");
				SM(azonosító + x + név + x + rang + x + életkor + x + szolgKezdete);

			}
			rs.close();
		} catch (SQLException e) {
			SM("ReadAllData: " + e.getMessage());
		}
		DisConnect(conn);

		cm.FoMenu();
	}

	public void ReadAllDataKatonak() throws SQLException { 												// TABLAK KIOLVAS KATONAK

		String sorszám = "", név = "", rang = "", x = "\t", sorszámFK = "";
		int életkor = 0;

		String sqlp = "SELECT sorszám, név, rang, életkor, sorszámFK FROM Katonak";

		Connection conn = Connect();

		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(sqlp);
			while (rs.next()) {
				sorszám = rs.getString("sorszám");
				név = rs.getString("név");
				rang = rs.getString("rang");
				életkor = rs.getInt("életkor");
				sorszámFK = rs.getString("sorszámFK");
				SM(sorszám + x + név + x + rang + x + életkor + x + sorszámFK);

			}
			rs.close();
		} catch (SQLException e) {
			SM("ReadAllData: " + e.getMessage());
		}
		DisConnect(conn);

		cm.FoMenu();
	}

	public void deleteDataTisztek() throws SQLException { 												// DELETE TISZTEK

		String azonosító = "";

		do {
			azonosító = cm.ReadData("Adja meg az azonositojat annak a tisztnek, akit torolni szeretne: ");

		} while (azonosító.length() != 6);

		Connection conn = Connect();
		String sqlp = "DELETE From Tisztek WHERE azonosító= '" + azonosító + "'";
		try {
			Statement s = conn.createStatement();
			int db = s.executeUpdate(sqlp);
			if (db == 0) {
				SM("A megadott tiszt nem létezik,nem törölhető!");
			} else {
				SM("Törlődött az " + azonosító + " azonosítójú tiszt!");
			}
		} catch (SQLException e) {
			SM("JDBC DeleteData: " + e.getMessage());
		}
		DisConnect(conn);

		cm.FoMenu();
	}

	public void deleteDatakatonak() throws SQLException { 												// DELETE KATONAK

		String sorszám = "";

		do {
			sorszám = cm.ReadData("Adja meg a sorszamat annak a katonanak, akit torolni szeretne: ");

		} while (sorszám.length() != 6);

		Connection conn = Connect();
		String sqlp = "DELETE From Katonak WHERE sorszám= '" + sorszám + "'";
		try {
			Statement s = conn.createStatement();
			int db = s.executeUpdate(sqlp);
			if (db == 0) {
				SM("A megadott katona nem létezik,nem törölhető!");
			} else {
				SM("Törlődött az " + sorszám + " azonosítójú katona!");
			}
		} catch (SQLException e) {
			SM("JDBC DeleteData: " + e.getMessage());
		}
		DisConnect(conn);

		cm.FoMenu();
	}

	public void UpdateDataTisztek() throws SQLException { 												// UPDATE TISZTEK

		String azonosító = "", mezo = "", mezoertek = "";

		do {
			azonosító = cm.ReadData("Adja meg az azonositojat annak a tisztnek, akin modosítani szeretne: ");

		} while (azonosító.length() != 6);

		do {
			mezo = cm.ReadData("Adja meg azt a mezot, amin modosítani szeretne: ");

		} while (mezo.equalsIgnoreCase("azonosító") && (mezo.equalsIgnoreCase("név"))
				&& (mezo.equalsIgnoreCase("életkor")) && (mezo.equalsIgnoreCase("rang"))
				&& (mezo.equalsIgnoreCase("szolgKezdete")));

		mezoertek = cm.ReadData("Adja meg az uj erteket: ");

		Connection conn = Connect();
		String sqlp = "UPDATE Tisztek SET " + mezo + "= '" + mezoertek + "' WHERE azonosító= '" + azonosító + "'";
		try {
			Statement s = conn.createStatement();
			int db = s.executeUpdate(sqlp);
			if (db == 0) {
				SM("A megadott tiszt nem létezik,nem módosítható!");
			} else {
				SM("Módosult az " + azonosító + " azonosítójú tiszt!");
			}
		} catch (SQLException e) {
			SM("JDBC DeleteData: " + e.getMessage());
		}
		DisConnect(conn);

		cm.FoMenu();

	}

	public void UpdateDataKatonak() throws SQLException { 												// UPDATE KATONAK

		String sorszám = "", mezo = "", mezoertek = "";

		do {
			sorszám = cm.ReadData("Adja meg a sorszamat annak a katonanak, akin modosítani szeretne: ");

		} while (sorszám.length() != 6);

		do {
			mezo = cm.ReadData("Adja meg azt a mezot, amin modosítani szeretne: ");

		} while (mezo.equalsIgnoreCase("sorszám") && (mezo.equalsIgnoreCase("név"))
				&& (mezo.equalsIgnoreCase("életkor")) && (mezo.equalsIgnoreCase("rang"))
				&& (mezo.equalsIgnoreCase("sorszámFK")));

		mezoertek = cm.ReadData("Adja meg az uj erteket: ");

		Connection conn = Connect();
		String sqlp = "UPDATE Katonak SET " + mezo + "= '" + mezoertek + "' WHERE sorszám= '" + sorszám + "'";
		try {
			Statement s = conn.createStatement();
			int db = s.executeUpdate(sqlp);
			if (db == 0) {
				SM("A megadott katona nem létezik,nem módosítható!");
			} else {
				SM("Módosult az " + sorszám + " azonosítójú katona!");
			}
		} catch (SQLException e) {
			SM("JDBC DeleteData: " + e.getMessage());
		}
		DisConnect(conn);

		cm.FoMenu();

	}

	public void isUserValid(String felhasznalonev, String jelszo) throws SQLException { 				// USER VALIDALASA

		// TODO Auto-generated method stub

		int counter = -1;
		String sqlp = "SELECT count(*) FROM Users WHERE username = '" + felhasznalonev + "' AND psw = '" + jelszo
				+ "' ";
		Connection conn = Connect();

		try {

			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(sqlp);

			while (rs.next()) {
				counter = rs.getInt(1);
			}
			rs.close();
		} catch (SQLException e) {

			SM(e.getMessage());

		}

		if (counter >= 1) {

			System.out.println("Belepes engedelyezve! \n");
			cm.FoMenu();

		} else {

			System.out.println("Belepes megtagadva! \n");
			cm.Bejelentkezes();

		}

		DisConnect(conn);

	}

	public void lekerdezesTisztek() throws SQLException {												//RESZLETES LEKERDEZES TISZTEK
		String azonosító = "", név = "", rang = "", szolgKezdete = "", sqlp;
		int életkor = 0;
		int InputIndex = 0, InputMeret = 0, i = 0;
		String[] Mutato = new String[5];

		int[] Tabla = new int[10];

		do {

			InputMeret = cm.ReadDataInt("Add meg, hogy hány mezőt szeretnél lekérdezni! (1 es 10 között!)");

		} while ((InputMeret < 1) || (InputMeret > 10));

		do {

			InputIndex = cm.ReadDataInt("[" + (i + 1)
					+ "] Válassz egyet! \n(0)Azonosito | (1)Nev | (2)Rang | (3)Eletkor| (4)Szolgalat kezdete");

			if ((InputIndex >= 0) && (InputIndex < 5)) {

				Tabla[i] = InputIndex;
				i++;

			}

		} while ((InputIndex < 0) || (InputIndex > 4) || (InputMeret != i));

		sqlp = "SELECT azonosító,név,rang,életkor,szolgKezdete FROM Tisztek";
		Connection conn = Connect();
		try {

			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(sqlp);
			while (rs.next()) {
				azonosító = rs.getString("azonosító");
				név = rs.getString("név");
				rang = rs.getString("rang");
				életkor = rs.getInt("életkor");
				szolgKezdete = rs.getString("szolgKezdete");

				Mutato[0] = azonosító;
				Mutato[1] = név;
				Mutato[2] = rang;
				Mutato[3] = String.valueOf(életkor);
				Mutato[4] = szolgKezdete;

				i = 0;

				int max = 0;
				for (int j = 0; j < Tabla.length; j++) {
					if (Tabla[j] > max) {
						max = Tabla[j];
					}
				}

				do {

					System.out.print(Mutato[Tabla[i]] + "\t");

					if (String.valueOf(Tabla[i]).equals(String.valueOf(max))) {
						System.out.println();
					}

					i++;

				} while ((i != InputMeret));

			}
			rs.close();

		} catch (SQLException e) {
			SM("ReadAllData: " + e.getMessage());
		}
		DisConnect(conn);

		cm.FoMenu();

	}

	public void lekerdezesKatonak() throws SQLException {												//RESZLETES LEKERDEZES KATONAK
		String sorszám = "", név = "", rang = "", sorszámFK = "", sqlp = "";
		int életkor = 0;

		int InputIndex = 0, InputMeret = 0, i = 0;
		String[] Mutato = new String[5];

		int[] Tabla = new int[10];

		do {

			InputMeret = cm.ReadDataInt("Add meg, hogy hány mezőt szeretnél lekérdezni! (1 es 10 között!)");

		} while ((InputMeret < 1) || (InputMeret > 10));

		do {

			InputIndex = cm.ReadDataInt("[" + (i + 1)
					+ "] Válassz egyet! \n(0)Sorszam | (1)Nev | (2)Rang | (3)Eletkor| (4)Felettese azonositoja");

			if ((InputIndex >= 0) && (InputIndex < 5)) {

				Tabla[i] = InputIndex;
				i++;

			}

		} while ((InputIndex < 0) || (InputIndex > 4) || (InputMeret != i));

		sqlp = "SELECT sorszám,név,rang,életkor,sorszámFK FROM Katonak";
		Connection conn = Connect();
		try {

			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(sqlp);
			while (rs.next()) {
				sorszám = rs.getString("sorszám");
				név = rs.getString("név");
				rang = rs.getString("rang");
				életkor = rs.getInt("életkor");
				sorszámFK = rs.getString("sorszámFK");

				Mutato[0] = sorszám;
				Mutato[1] = név;
				Mutato[2] = rang;
				Mutato[3] = String.valueOf(életkor);
				Mutato[4] = sorszámFK;

				i = 0;

				int max = 0;
				for (int j = 0; j < Tabla.length; j++) {
					if (Tabla[j] > max) {
						max = Tabla[j];
					}
				}

				do {

					System.out.print(Mutato[Tabla[i]] + "\t");

					if (String.valueOf(Tabla[i]).equals(String.valueOf(max))) {
						System.out.println();
					}

					i++;

				} while ((i != InputMeret));

			}
			rs.close();

		} catch (SQLException e) {
			SM("ReadAllData: " + e.getMessage());
		}
		DisConnect(conn);

		cm.FoMenu();

	}

}
