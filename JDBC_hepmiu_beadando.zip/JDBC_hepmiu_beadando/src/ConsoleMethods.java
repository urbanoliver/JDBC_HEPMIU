import java.sql.SQLException;
import java.util.Scanner;

public class ConsoleMethods {

	Scanner scanInput = new Scanner(System.in);
	static DbMethods dbm = new DbMethods();

	public String ReadData(String s) {																			//BEOLVASASOK

		String data = "";
		System.out.println(s);
		data = scanInput.nextLine();
		return data;
	}

	public int ReadDataInt(String s) {

		int i = 0;
		System.out.println(s);
		i = scanInput.nextInt();
		return i;
	}

	public void SM(String s) {																					//KIIRAS
		System.out.println(s + "\n");
	}
	
	public void Bejelentkezes() throws SQLException {															//BEJELENTKEZES MENUJE
		
		SM("\n");
		SM("Bejelentkezes");
		SM("====================================================");
		SM("Adja meg a felhasznalonevet es jelszavat!");
		SM("====================================================");
		String felhasznalonev = ReadData("Adja meg a felhasznalonevet! ");
		SM("====================================================");
		String jelszo = ReadData("Adja meg a jelszavat! ");
		
		
		dbm.isUserValid(felhasznalonev,jelszo);
		
	}

	

	public void FoMenu() throws SQLException {																	//FOMENU HIVASA

		SM("\n");
		SM("Fomenu");
		SM("====================================================");
		SM("Valassza ki melyik tablan szeretne muveletet vegezni!");
		SM("====================================================");
		SM("1.Tisztek");
		SM("2.Katonak");
		SM("0.Kilepes");

		/*String ms = ReadData("Adja meg a menü sorszamat: ");
		int n = -1;
		if (test(ms)) {
			n = StringToInt(ms);
		}*/
		
		
		int n = 0;
		do
		{
			
			n = ReadDataInt("Kérem a válaszott menü számát! ");
			
		}
		while( (n < 0) || (n > 6) );
		
		switch (n) {

		case 1:
			MenuTisztek();
			break;
		case 2:
			MenuKatonak();
			break;
		case 0:
			SM("Kilepunk a programbol! ");
			System.exit(0);

		}

	}

	public void MenuTisztek() throws SQLException {																//TISZTEK ALMENU HIVASA

		SM("\n");
		SM("TISZTEK");
		SM("==============================================");
		SM("Valassza ki milyen muveletet szeretne vegezni!");
		SM("==============================================");

		SM("0.Kilepes");
		SM("1.Listazas");
		SM("2.Beszuras");
		SM("3.Torles");
		SM("4.Modositas");
		SM("5.Lekerdezes");

	
		int n = 0;
		do
		{
			
			n = ReadDataInt("Kérem a válaszott menü számát! ");
			
		}
		while( (n < 0) || (n > 6) );
		
		
		
		switch (n) {

		case 0:
			SM("Kiléptunk a programbol! ");
			System.exit(0);
		case 1:
			dbm.ReadAllDataTisztek();
			break;
		case 2:
			dbm.insertTisztek();
			break;
		case 3:
			dbm.deleteDataTisztek();
			break;
		case 4:
			dbm.UpdateDataTisztek();
			break;
			
		case 5:
			dbm.lekerdezesTisztek();
			break;

		}
	}

	public void MenuKatonak() throws SQLException {																//KATONAK ALMENU HIVASA

		SM("\n");
		SM("KATONAK");
		SM("=============================================");
		SM("Valassza ki milyen muveletet szeretne vegezni!");
		SM("=============================================");

		SM("0.Kilepes");
		SM("1.Listazas");
		SM("2.Beszuras");
		SM("3.Torles");
		SM("4.Modositas");
		SM("5.Lekerdezes");

		
		int n = 0;
		do
		{
			
			n = ReadDataInt("Kérem a válaszott menü számát! ");
			
		}
		while( (n < 0) || (n > 6) );
		
		switch (n) {

		case 0:
			SM("Kileptunk a programbol! ");
			System.exit(0);
		case 1:
			dbm.ReadAllDataKatonak();
			break;
		case 2:
			dbm.insertKatonak();
			break;
		case 3:
			dbm.deleteDatakatonak();
			break;
		case 4:
			dbm.UpdateDataKatonak();
			break;
		case 5:
			dbm.lekerdezesKatonak();
			break;
		}

	}

	public boolean test(String ms) {																			//MENU INPUT TEST
		if (ms.length() == 0) {

			SM("Adja meg ujra!");
			return false;
		} else {
			try {
				int number = Integer.valueOf(ms);
				if (number >= 0 && number <= 5) {
					return true;
				} else {
					SM("Hibasan megadott szam!");
					return false;
				}
			} catch (NumberFormatException nfe) {
				SM("Ez is hibas input!");
				return false;
			}
		}
	}

	public static int StringToInt(String ms) {																//KONVERTALAS STRING TO INT

		int number = 0;

		try {
			number = Integer.valueOf(ms);

		} catch (NumberFormatException nfe) {
			System.out.println("StringToInt: " + nfe.getMessage());
		}

		return number;
	}

}
