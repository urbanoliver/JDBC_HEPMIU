import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class Program {

	static DbMethods dbm = new DbMethods();
	static ConsoleMethods cm = new ConsoleMethods();
	
	public static void main(String[] args) throws SQLException {
		dbm.Reg();
		
		//dbm.DisConnect(dbm.Connect());
		
		//dbm.createTable();
		
		//dbm.insertUsers();
		
		cm.Bejelentkezes();
		
		
		
		
	}
	

}
